# tools/ui_smoke.gd
# Prueba de humo E2E de la UI: abre el Hub, verifica que las tarjetas de juego
# sean visibles y clicables (regresión del bug "no hay botones"), hace clic en
# la primera y confirma la navegación al minijuego. Guarda capturas en /tmp/shots.
# Requiere display (o xvfb); NO modifica project.godot:
#   DISPLAY=:98 godot --path . -s tools/ui_smoke.gd
extends SceneTree

const SHOTS := "/tmp/shots/"


func _init() -> void:
	run_smoke()


func run_smoke() -> void:
	print("=== UI Smoke Test ===")
	change_scene("res://scenes/HubCentral.tscn")
	yield(create_timer(0.8), "timeout")
	var hub = current_scene
	if hub == null or hub.name != "HubCentral":
		print("  [FALLO] El Hub no cargó (current_scene=%s)" % (hub.name if hub else "null"))
		OS.exit_code = 1
		quit()
		return
	shot("01_hub")
	var scroll = hub.get_node("VBoxContainer/GameGrid")
	var tiles = hub.get_node("VBoxContainer/GameGrid/GridContainer")
	var cards = tiles.get_children()
	print("  Tarjetas de juego encontradas: %d" % cards.size())
	var vp_rect: Rect2 = Rect2(Vector2.ZERO, get_root().size)
	# Regresión del bug: el área scrolleable no puede colapsar a altura 0
	if scroll.rect_size.y < 100:
		print("  [FALLO] GameGrid colapsado: altura=%f" % scroll.rect_size.y)
		OS.exit_code = 1
		quit()
		return
	# La primera tarjeta debe estar visible sin scrollear
	var first: Rect2 = cards[0].get_global_rect()
	if not vp_rect.encloses(first):
		print("  [FALLO] La primera tarjeta no es visible sin scrollear: %s" % first)
		OS.exit_code = 1
		quit()
		return
	print("  [OK] Primera tarjeta visible y clicable: %s" % first)
	# El resto debe ser alcanzable haciendo scroll hasta el final
	scroll.scroll_vertical = 99999
	yield(create_timer(0.3), "timeout")
	var last: Rect2 = cards[cards.size() - 1].get_global_rect()
	if not vp_rect.encloses(last):
		print("  [FALLO] La última tarjeta no es alcanzable con scroll: %s" % last)
		OS.exit_code = 1
		quit()
		return
	print("  [OK] Última tarjeta alcanzable con scroll: %s" % last)
	scroll.scroll_vertical = 0
	yield(create_timer(0.2), "timeout")
	var btn = find_button(cards[0])
	if btn == null:
		print("  [FALLO] La primera tarjeta no tiene botón jugable")
		OS.exit_code = 1
		quit()
		return
	print("  Pulsando botón '%s' de la tarjeta 1..." % btn.text)
	click_center(btn)
	yield(create_timer(0.8), "timeout")
	shot("02_game")
	if current_scene == null or current_scene.name == "HubCentral":
		print("  [FALLO] El clic en la tarjeta no navegó al minijuego")
		OS.exit_code = 1
	else:
		print("  [OK] Navegación al minijuego: %s" % current_scene.name)
	print("=== Fin UI Smoke Test ===")
	quit()


func shot(n: String) -> void:
	var img = get_root().get_texture().get_data()
	img.save_png(SHOTS + n + ".png")


func find_button(n: Node):
	if n is Button:
		return n
	for c in n.get_children():
		var b = find_button(c)
		if b != null:
			return b
	return null


func click_center(c: Control) -> void:
	var r: Rect2 = c.get_global_rect()
	var p: Vector2 = r.position + r.size * 0.5
	for pressed in [true, false]:
		var ev := InputEventMouseButton.new()
		ev.button_index = BUTTON_LEFT
		ev.pressed = pressed
		ev.position = p
		ev.global_position = p
		Input.parse_input_event(ev)
