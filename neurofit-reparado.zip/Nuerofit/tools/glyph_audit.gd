# tools/glyph_audit.gd
# Auditoría de cobertura de glifos de la fuente activa del proyecto
# (res://assets/fonts/default_theme.tres).
#
# Los estímulos de los minijuegos (symbols.speed, head.count), el pad numérico
# (⌫) y las flechas de tendencia usan glifos que la fuente por defecto de
# Godot 3.5 NO cubre y se dibujaban en blanco (juegos injugables). Esta
# herramienta renderiza cada glifo necesario y lo compara píxel a píxel contra
# el glifo .notdef (U+E000, garantizado como ausente): si el bitmap coincide,
# el glifo falta en la fuente.
#
# Uso (requiere display o xvfb; sale con código 1 si falta algún glifo):
#   DISPLAY=:98 godot --path . -s tools/glyph_audit.gd
extends SceneTree

const CELL := 160
const COLS := 8
const NOTDEF := ""

# Glifos que la UI y los estímulos de los minijuegos necesitan renderizar.
const GLYPHS := [
	"A", "0", "+", "×", "·", "—", "…", "¡",
	"⌫", "→", "↑", "↓", "✓", "✗", "<", ">",
	"●", "■", "▲", "★", "◆", "♥", "✚", "○",
	"□", "△", "◇", "☆", "♡", "♟",
]


func _init() -> void:
	run()


func run() -> void:
	yield(create_timer(0.4), "timeout")
	var font: Font = Control.new().get_font("font", "Label")
	var big := DynamicFont.new()
	big.size = 48
	if font is DynamicFont:
		big.font_data = font.font_data
	var entries := []
	for g in GLYPHS:
		entries.append(g)
	entries.append(NOTDEF)
	for i in range(entries.size()):
		var l := Label.new()
		l.text = entries[i]
		if big.font_data:
			l.add_font_override("font", big)
		l.rect_position = Vector2((i % COLS) * CELL + 56, int(i / COLS) * CELL + 40)
		get_root().add_child(l)
	yield(create_timer(0.4), "timeout")
	var img := get_root().get_texture().get_data()
	var H: int = img.get_height()
	var nd: PoolByteArray = cell_bytes(img, H, entries.size() - 1)
	print("=== Auditoría de glifos (bitmap vs .notdef) ===")
	var missing := 0
	for i in range(GLYPHS.size()):
		var d: PoolByteArray = cell_bytes(img, H, i)
		if bytes_equal(d, nd):
			missing += 1
			print("  [FALTA] %s U+%04X (se dibuja como .notdef)" % [GLYPHS[i], GLYPHS[i].ord_at(0)])
	if missing == 0:
		print("  [OK] %d glifos renderizan correctamente" % GLYPHS.size())
		OS.exit_code = 0
	else:
		print("  [FALLO] %d glifos sin cubrir por la fuente activa" % missing)
		OS.exit_code = 1
	print("=== Fin auditoría ===")
	quit()


func cell_bytes(img: Image, H: int, idx: int) -> PoolByteArray:
	var col: int = idx % COLS
	var row: int = int(idx / COLS)
	# El bitmap del viewport tiene origen abajo-izquierda: invertir filas.
	return img.get_rect(Rect2(col * CELL, H - (row + 1) * CELL, CELL, CELL)).get_data()


func bytes_equal(a: PoolByteArray, b: PoolByteArray) -> bool:
	if a.size() != b.size():
		return false
	for i in range(a.size()):
		if a[i] != b[i]:
			return false
	return true
