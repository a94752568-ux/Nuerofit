# tests/test_hub_layout.gd
# Prueba de regresión del bug "no hay botones / no se pueden elegir los juegos":
# el ScrollContainer (GameGrid) del Hub colapsaba a altura 0 y dejaba las tarjetas
# de juego fuera del viewport. Verifica los invariantes de layout de la escena.
extends SceneTree


func run() -> bool:
	print("--- Prueba: Layout del Hub (GameGrid visible y tarjetas clicables) ---")
	var ps = load("res://scenes/HubCentral.tscn")
	if ps == null:
		print("  [FALLO] No se pudo cargar scenes/HubCentral.tscn")
		return false
	var root = ps.instance()
	var grid = root.get_node("VBoxContainer/GameGrid")
	var tiles = root.get_node("VBoxContainer/GameGrid/GridContainer")
	var ok = true
	if grid == null or tiles == null:
		print("  [FALLO] Nodos GameGrid/GridContainer no encontrados")
		return false
	# 1) Altura mínima garantizada (evita colapso a 0)
	if grid.rect_min_size.y < 200:
		print("  [FALLO] GameGrid.rect_min_size.y = %f (< 200)" % grid.rect_min_size.y)
		ok = false
	# 2) Debe expandirse verticalmente dentro del VBox
	if grid.size_flags_vertical != Control.SIZE_EXPAND_FILL:
		print("  [FALLO] GameGrid.size_flags_vertical = %d (esperado SIZE_EXPAND_FILL)" % grid.size_flags_vertical)
		ok = false
	# 3) Sin scroll horizontal: las tarjetas se apilan en columnas visibles
	if grid.scroll_horizontal_enabled:
		print("  [FALLO] GameGrid.scroll_horizontal_enabled = true (las tarjetas quedarían fuera del viewport)")
		ok = false
	# 4) Sin ancho hardcodeado en el contenedor de tarjetas
	if tiles.rect_min_size.x > 0:
		print("  [FALLO] GridContainer.rect_min_size.x = %f (ancho forzado)" % tiles.rect_min_size.x)
		ok = false
	if tiles.columns < 1:
		print("  [FALLO] GridContainer.columns = %d" % tiles.columns)
		ok = false
	if ok:
		print("  [OK] Invariantes de layout del Hub correctos")
	else:
		print("  [FALLO] El Hub no garantiza tarjetas visibles y clicables")
	root.free()
	return ok
